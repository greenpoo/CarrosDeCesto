package greenpoo.derby;

import greenfoot.Actor;

public class Barrel extends Actor
{
	public Barrel()
	{
		setImage("barrel.png"); // é atribuida a imagem respetiva
	}
}
