package greenpoo.derby; 

import greenfoot.Actor;

public class BoostPickup extends Actor {
	public BoostPickup() {
		setImage("gold-ball.png"); // é atribuida a imagem respetiva
	}
}
